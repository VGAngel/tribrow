package ru.spu.cache.msg;

public class RemoveAll<K, V> implements Message<K, V> {

}
