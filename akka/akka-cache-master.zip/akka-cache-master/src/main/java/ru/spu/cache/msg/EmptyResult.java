package ru.spu.cache.msg;

import java.io.Serializable;

public class EmptyResult<K, V> implements Message<K, V>, Serializable {

}
