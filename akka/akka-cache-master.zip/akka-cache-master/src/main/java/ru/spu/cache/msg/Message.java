package ru.spu.cache.msg;

public interface Message<K, V> {

}
