package ru.spu.cache.msg;

public class GetStatistics<K, V> implements Message<K, V> {

}
