package de.fhopf.akka.actor;

/**
 *
 * @author Florian Hopf, http://www.florian-hopf.de
 */
public final class IndexedMessage {
    
    public final String path;

    public IndexedMessage(String path) {
        this.path = path;
    }
    
}
