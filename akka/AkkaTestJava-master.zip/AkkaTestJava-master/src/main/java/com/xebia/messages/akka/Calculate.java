package com.xebia.messages.akka;

public class Calculate {
}
