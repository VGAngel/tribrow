This is a simple sample project showing AKKA in Java. It is a simple code that shows how easy it is to setup AKKA and how big the performance gain is.
