package chat.events;

import java.io.Serializable;

/**
 * ChatServer's internal events.
 */
public abstract class Event implements Serializable {

	private static final long serialVersionUID = -1354942905395394545L;

}