/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

import java.awt.EventQueue;

/**
 *
 * @author beschastnov
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        EventQueue.invokeLater(new Runnable() {

            public void run() {
                GUI frame = new GUI();
                frame.setVisible(true);
            }
        });
    }

}
